<?php 

				echo '<hr/>';
				echo '<p class="description">';
				  echo 'This ';
				  echo get_bloginfo( "name" );
				  echo ' Plugin powered by <a href="http://wp.devuri.com">Devuri</a>';
				  echo '</p>';
				echo '</div>';