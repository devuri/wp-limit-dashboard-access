<?php 

		
		// add pop 
		add_thickbox();
				echo '<div class="wrap">';
				//screen_icon(); 
				echo '<h2>';
				echo lide_info('name');
				echo '</h2>';
				echo'<p class="description"> '.lide_info('name').' - '.lide_info('description').' </p>';
				// check dependencies